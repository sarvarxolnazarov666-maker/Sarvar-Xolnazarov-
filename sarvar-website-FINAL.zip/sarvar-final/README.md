# Sarvar Xolnazarov — Shaxsiy Veb-Sayt

## Tezkor ishga tushirish

### GitHub → Vercel (5 daqiqa)
1. github.com → New repository → "sarvar-website"
2. Fayllarni yuklang
3. vercel.com → Import → Deploy ✅

## Telegram Bot ulash (ixtiyoriy)
index.html da qidiring: `7XXXXXXXXX:AA`
1. Telegram → @BotFather → /newbot → token oling
2. Token ni kiriting: TOKEN = 'sizning_token'
3. @userinfobot ga yozing → CHAT_ID ni oling
4. CHAT_ID = 'sizning_chat_id'

## Rasm
Rasm allaqachon fayl ichida (base64). Almashtirish kerak bo'lsa:
index.html da `data:image/jpeg;base64,` ni toping va yangi rasm bilan almashtiring.

## Kontakt
+998 95 986 64 26 | @ijtxodim202
