Bu papka zaxira uchun.
Rasm allaqachon index.html ichida (base64 formatda).
Alohida rasm fayli kerak emas.
