# 🌐 Sarvar Xolnazarov — Shaxsiy Veb-Sayt

> Professional Ijtimoiy Xodim | AI Mutaxassis | Pedagog | Vikipedist

## 🚀 GitHub → Vercel (5 daqiqa)

### 1-qadam: GitHub ga yuklash
```
1. github.com → "New repository"
2. Nom: sarvar-website
3. Public → Create repository
4. "Upload files" → barcha fayllarni yuklang → Commit
```

### 2-qadam: Vercel ga deploy
```
1. vercel.com → "Add New Project"
2. GitHub dan sarvar-website ni tanlang
3. "Deploy" tugmasini bosing
4. Tayyor! → sarvar-website.vercel.app ✅
```

### 3-qadam: O'z domeningizni ulash (ixtiyoriy)
```
Vercel → Project → Settings → Domains
→ sarvarxolnazarov.uz yoki .com qo'shing
```

---

## 📁 Fayl tuzilmasi

```
sarvar-website/
├── index.html          ← Butun sayt (rasm ichida embed)
├── vercel.json         ← Vercel deploy sozlamalari
├── .gitignore          ← Git uchun
├── images/             ← (zaxira papka, hozir bo'sh)
└── README.md           ← Bu fayl
```

---

## ⚙️ Telegram Bot ulash

`index.html` faylida qidiring: `7XXXXXXXXX:AA`

**1. Bot token olish:**
```
Telegram → @BotFather → /newbot
→ Bot nomi: SarvarXolnazarov_bot
→ Token: 7xxxxxxxxx:AAxxxxxxxxxxxxxxx
```

**2. Chat ID olish:**
```
Telegram → @userinfobot → /start
→ Your ID: 123456789
```

**3. index.html da almashtiring:**
```javascript
const TOKEN   = '7XXXXXXXXX:AA...';  // ← shu yerga
const CHAT_ID = 'SIZNING_CHAT_ID';   // ← shu yerga
```

---

## ✨ Sayt xususiyatlari

| Xususiyat | Tavsif |
|---|---|
| 🌐 Ko'p tilli | O'zbek / Rus / Ingliz |
| 🖼️ Rasm | Base64 — alohida fayl kerak emas |
| 🤖 AI Chatbot | Sarvar haqida savollar |
| 📅 Uchrashuv | Calendly integratsiya |
| 📋 Mijozlar | localStorage da saqlanadi |
| 📊 CSV | Mijozlar ro'yxatini yuklash |
| 📢 Yangiliklar | @ijtimoiyhimoya_agentligi |
| 🔵 Scroll panel | O'ng tomonda navigatsiya |
| ✈ Telegram | @ijtxodim202 to'g'ridan-to'g'ri |
| 📱 Responsiv | Mobil va desktop |

---

## 📞 Bog'lanish

- 📱 Telefon: +998 95 986 64 26
- ✈ Telegram: [@ijtxodim202](https://t.me/ijtxodim202)
- 📢 Kanal: [@ijtimoiyhimoya_agentligi](https://t.me/ijtimoiyhimoya_agentligi)

---

*© 2024 Sarvar Xolnazarov. Barcha huquqlar himoyalangan.*
